#!/usr/bin/env python3
"""Generate the Velvet Chords MPC screen skin.

Output: <out>/Velvet Chords - VST - Velvet Chords/
  TUI.json                 pages, component definitions, parameter bindings
  Q-Links.json             Q-Link assignments per page
  Q-Links - 8by1.json      same, for 8-Q-Link hardware (identical, as in the JV-880 reference)
  *.png                    every image the pages use

The file format mirrors a working community skin (JV-880 by sd88me) supplied as reference; it is not documented by
Akai. Parameters are bound by NAME: indices come from the built plugin via tools/list_params, so the skin can't drift
from the code.

Visual language: flat studio hardware. Dark surfaces, 1px hairlines, small tracked uppercase labels, one amber
accent reserved for state (selected, playing). No gloss, no gradients on controls, no drop shadows.
Every image is drawn at 3x and downsampled for clean edges.

usage: make_skin.py <plugin.so> <list_params binary> <out dir>
"""
import json, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 628
SS = 3
FONT_DIR = "/usr/share/fonts/truetype/google-fonts"
LIVE_FONT = "Titillium Web"  # font the MPC uses for live text in the reference skin

# ---- palette
BG = "#0e0f11"
HEADER = "#131417"
SURFACE = "#16171a"       # panels
HAIRLINE = "#25272c"
CTRL = "#1b1d21"          # unselected control fill
CTRL_EDGE = "#2c2f35"
CTRL_SEL = "#23262b"      # selected control fill
FIELD = "#0b0c0e"
FIELD_EDGE = "#2a2d33"
ACCENT = "#f2a33a"
ACCENT_DIM = "#8a5f25"
INK_ON_ACCENT = "#17120a"
TEXT = "#e8e9eb"
TEXT_2 = "#a4a8b0"
LABEL = "#6c7079"
KEY_WHITE = "#dededa"; KEY_WHITE_EDGE = "#a9a9a4"; KEY_BLACK = "#1d1f23"
GOLD = ACCENT  # names used by older helpers
ROSE = ACCENT
BRIGHT = TEXT
MUTED = TEXT_2
INK = TEXT


def argb(hexrgb, a="ff"):
    return a + hexrgb.lstrip("#")


def font(weight, size):
    return ImageFont.truetype(os.path.join(FONT_DIR, "Poppins-%s.ttf" % weight), int(round(size)))


# ---------------------------------------------------------------- parameters
def load_params(so, lister):
    out = subprocess.run([lister, so], capture_output=True, text=True, check=True).stdout
    p = {}
    for line in out.splitlines():
        i, name = line.split("\t")[:2]
        p[name] = int(i)
    return p


# ---------------------------------------------------------------- drawing
class Art:
    """Draw at SS x in final-pixel coordinates; downsample on save."""

    def __init__(self, w, h, bg=None):
        self.w, self.h = w, h
        self.im = Image.new("RGBA", (w * SS, h * SS), bg or (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    def s(self, *v):
        return [x * SS for x in v]

    def rect(self, x0, y0, x1, y1, r=0, fill=None, edge=None, width=1, corners=(True, True, True, True)):
        self.d.rounded_rectangle(self.s(x0, y0, x1 - 1, y1 - 1), r * SS, fill=fill, outline=edge, width=int(width * SS), corners=corners)

    def line(self, x0, y0, x1, y1, fill, width=1):
        self.d.line(self.s(x0, y0, x1, y1), fill=fill, width=int(width * SS))

    def text(self, x, y, txt, size, fill, weight="Medium", anchor="la", tracking=0.0):
        f = font(weight, size * SS)
        if not tracking:
            self.d.text((x * SS, y * SS), txt, font=f, fill=fill, anchor=anchor)
            return
        widths = [self.d.textlength(c, font=f) for c in txt]
        total = sum(widths) + tracking * SS * (len(txt) - 1)
        cx = x * SS - (total / 2 if anchor[0] == "m" else total if anchor[0] == "r" else 0)
        for c, w in zip(txt, widths):
            self.d.text((cx, y * SS), c, font=f, fill=fill, anchor="l" + anchor[1])
            cx += w + tracking * SS

    def text_center(self, x0, y0, x1, y1, txt, size, fill, weight="Medium", tracking=0.0):
        f = font(weight, size * SS)
        _, t, _, b = self.d.textbbox((0, 0), "HX", font=f)
        y = (y0 + y1) / 2 * SS - (b - t) / 2 - t
        self.text((x0 + x1) / 2, y / SS, txt, size, fill, weight, anchor="ma", tracking=tracking)

    def label(self, x, y, txt):
        """section/control label: small, uppercase, tracked"""
        self.text(x, y, txt.upper(), 10.5, LABEL, "Medium", tracking=1.3)

    def done(self):
        return self.im.resize((self.w, self.h), Image.LANCZOS)


class Images:
    def __init__(self, outdir):
        self.dir = outdir
        self.made = set()

    def save(self, name, img):
        if name not in self.made:
            img.save(os.path.join(self.dir, name), optimize=True)
            self.made.add(name)
        return name

    def pad(self, n, on):
        """MPC-style pad tile: dark, active = amber outline + underline"""
        w, h = 148, 120
        a = Art(w, h)
        if on:
            a.rect(1, 1, w - 1, h - 1, 6, fill=CTRL_SEL, edge=ACCENT, width=1.5)
            a.rect(10, h - 7, w - 10, h - 4, 1.5, fill=ACCENT)
        else:
            a.rect(1, 1, w - 1, h - 1, 6, fill=CTRL, edge=CTRL_EDGE, width=1)
        a.text(12, 10, "%02d" % n, 10.5, ACCENT if on else "#4d5159", "Medium", tracking=0.8)
        return self.save("vc_pad_%d_%s.png" % (n, "on" if on else "off"), a.done())

    def key(self, pc, on, small=False):
        black = pc in (1, 3, 6, 8, 10)
        names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        w, h = ((40, 74) if black else (64, 120)) if small else ((48, 90) if black else (80, 150))
        a = Art(w, h)
        if black:
            a.rect(0, 0, w, h, 3, fill=ACCENT if on else KEY_BLACK, edge="#08090a", corners=(False, False, True, True))
        else:
            a.rect(0, 0, w, h, 4, fill=ACCENT if on else KEY_WHITE, edge=KEY_WHITE_EDGE if not on else "#b97a22",
                   corners=(False, False, True, True))
            yy = h - (46 if not small else 30)
            a.text_center(0, yy, w, yy + 16, names[pc], 12 if not small else 11, INK_ON_ACCENT if on else "#55575c", "Medium")
        return self.save("vc_%skey_%d_%s.png" % ("e" if small else "", pc, "on" if on else "off"), a.done())

    def dot(self, on_black):
        a = Art(14, 14)
        a.d.ellipse(a.s(3, 3, 11, 11), fill="#c9ccd2" if on_black else "#26282c")
        return self.save("vc_dot_%s.png" % ("b" if on_black else "w"), a.done())

    def blank(self, w, h):
        return self.save("vc_blank_%dx%d.png" % (w, h), Image.new("RGBA", (w, h), (0, 0, 0, 0)))

    def seg(self, group, i, n, text, w, h, on):
        """joined segmented control: shared 1px dividers, selected = lifted cell, amber text, amber underline"""
        a = Art(w, h)
        first, last = i == 0, i == n - 1
        corners = (first, last, last, first)
        a.rect(0, 0, w, h, 5, fill=CTRL_SEL if on else CTRL, corners=corners)
        a.rect(0, 0, w, h, 5, edge=CTRL_EDGE, corners=corners)
        if not first:
            a.line(0, 0, 0, h, CTRL_EDGE)
        if on:
            a.rect(8, h - 4, w - 8, h - 2, 1, fill=ACCENT)
        size = 13 if w >= 60 else 12
        a.text_center(0, 0, w, h - 1, text, size, ACCENT if on else TEXT_2, "Medium" if on else "Regular")
        return self.save("vc_seg_%s_%d_%s.png" % (group, i, "on" if on else "off"), a.done())

    def chevron(self, nxt):
        a = Art(36, 36)
        pts = [(16, 12), (21, 18), (16, 24)] if nxt else [(20, 12), (15, 18), (20, 24)]
        a.d.line([(x * SS, y * SS) for x, y in pts], fill=TEXT_2, width=int(1.8 * SS), joint="curve")
        return self.save("vc_chev_%s.png" % ("next" if nxt else "prev"), a.done())

    def chevron_pressed(self, nxt):
        a = Art(36, 36)
        a.rect(2, 2, 34, 34, 4, fill=CTRL_SEL)
        pts = [(16, 12), (21, 18), (16, 24)] if nxt else [(20, 12), (15, 18), (20, 24)]
        a.d.line([(x * SS, y * SS) for x, y in pts], fill=ACCENT, width=int(1.8 * SS), joint="curve")
        return self.save("vc_chev_%s_on.png" % ("next" if nxt else "prev"), a.done())

    def switch(self, on):
        w, h = 44, 24
        a = Art(w, h)
        a.rect(0, 0, w, h, 12, fill=ACCENT if on else CTRL, edge=None if on else CTRL_EDGE)
        cx = w - 12 if on else 12
        a.d.ellipse(a.s(cx - 8, 4, cx + 8, 20), fill=INK_ON_ACCENT if on else "#6c7079")
        return self.save("vc_switch_%s.png" % ("on" if on else "off"), a.done())

    def button(self, name, text, w, h, on):
        a = Art(w, h)
        a.rect(0, 0, w, h, 5, fill=ACCENT if on else CTRL, edge=ACCENT if on else CTRL_EDGE)
        a.text_center(0, 0, w, h, text, 13, INK_ON_ACCENT if on else TEXT, "Medium")
        return self.save("vc_btn_%s_%s.png" % (name, "on" if on else "off"), a.done())

    def cell(self, row, on, w, h, colour):
        a = Art(w, h)
        if on:
            a.rect(0, 0, w, h, 3, fill=colour)
        else:
            a.rect(0, 0, w, h, 3, fill=CTRL, edge=CTRL_EDGE)
        return self.save("vc_cell_%d_%s.png" % (row, "on" if on else "off"), a.done())


class Background:
    """Full-page art: header, panels, field frames and labels; live text sits on top."""

    def __init__(self, page_title):
        self.a = Art(W, H, bg=BG)
        a = self.a
        a.rect(0, 0, W, 56, 0, fill=HEADER)
        a.line(0, 56, W, 56, HAIRLINE)
        for k, wbar in enumerate((18, 13, 8)):  # logo mark: a chord stack
            a.rect(24, 19 + k * 7, 24 + wbar, 23 + k * 7, 1.5, fill=ACCENT)
        a.text(52, 28, "VELVET CHORDS", 14, TEXT, "Medium", anchor="lm", tracking=2.2)
        a.line(212, 18, 212, 38, HAIRLINE)
        a.text(226, 28, page_title.upper(), 11, ACCENT, "Medium", anchor="lm", tracking=1.6)

    @property
    def d(self):
        return self.a.d

    def panel(self, box, title=None):
        x0, y0, x1, y1 = box
        self.a.rect(x0, y0, x1, y1, 6, fill=SURFACE, edge=HAIRLINE)
        if title:
            self.a.label(x0 + 16, y0 + 12, title)

    def field(self, x, y, w, h):
        self.a.rect(x, y, x + w, y + h, 5, fill=FIELD, edge=FIELD_EDGE)

    def caption(self, x, y, txt):
        self.a.label(x, y, txt)

    def text(self, *args, **kw):
        self.a.text(*args, **kw)

    @property
    def im(self):
        return self.a.done().convert("RGB")


# ---------------------------------------------------------------- TUI.json building blocks
def remap(pairs):
    return {"version": 1, "map": [{"key": k, "value": "Parameter %d" % v} for k, v in pairs]}


def bounds(x, y, w, h, focus="No", visible="Always", invalid="Show", inval=None):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": invalid, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": "%d %d %d %d" % (x, y, w, h), "additionalInvalidatingHandles": inval or []}


def action(on, handler, overlay=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": overlay, "handle remapping": {"version": 1, "map": []}}


A_QLINK = action("Mouse Down", "Q-Link")
A_OVERLAY_DBL = action("Double Click", "Show Overlay", "knob overlay")
A_OVERLAY_ENTER = action("Enter Pressed", "Show Overlay", "knob overlay")
A_TOGGLE_ENTER = action("Enter Pressed", "Toggle Switch")
A_TOGGLE_DOWN = action("Mouse Down", "Toggle Switch")


def sub(name, ctype, data, b):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": ctype, "data": data},
            "handle remapping": {"version": 1, "map": []}, "bounds": b}


def focus_sub(w, h):
    return sub("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": argb(ROSE),
                                  "backgroundInset": 2.0, "outlineThickness": 2.0}, bounds(0, 0, w, h, visible="WhenFocussed"))


def label_sub(name, handle, x, y, w, h, size, colour, just="horizontallyCentred verticallyCentred"):
    return sub(name, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": LIVE_FONT, "style": "SemiBold",
               "height": float(size)}, "colour": argb(colour), "justification": just, "case": "Original"},
               "type": "Value", "handleName": handle}, bounds(x, y, w, h))


def button_sub(on, off, bid, n, w, h, x=0, y=0):
    return sub("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": bid, "numButtonsInGroup": n,
                                    "handleName": "Data", "gestureBehaviour": "Instant"}, bounds(x, y, w, h))


def definition(actions, comps, bgcolour="0", ignore=False):
    return {"version": 4, "actions": actions,
            "backgroundData": {"version": 1, "focussed": {"version": 1, "colour": bgcolour, "image": ""},
                               "unfocussed": {"version": 1, "colour": bgcolour, "image": ""}},
            "ignoreMousePresses": ignore, "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True,
            "componentsData": comps}


STEP_ROWS = [  # (step type index in the plugin, label, colour when set)
    (2, "Accent", ACCENT),
    (1, "Chord", "#b9832f"),
    (5, "Upper acc", "#6fb1db"),
    (4, "Upper", "#3f7fa8"),
    (3, "Bass", "#8f74d6"),
    (6, "Tie", "#5a5f69"),
    (0, "Rest", "#34373e"),
]

CH = 36  # standard control height


class Skin:
    def __init__(self, params, outdir):
        self.P = params
        self.img = Images(outdir)
        self.defs = {}
        self.pages = []

    def p(self, name):
        if name not in self.P:
            raise KeyError("plugin has no parameter %r" % name)
        return self.P[name]

    def define(self, key, value):
        if key not in self.defs:
            self.defs[key] = value
        return key

    @staticmethod
    def place(deftype, name, x, y, w, h, pairs, focus="No", inval=None):
        return {"version": 2, "componentData": {"version": 1, "name": name, "type": deftype, "data": {"version": 1, "handleName": "Data"}},
                "handle remapping": remap(pairs), "bounds": bounds(x, y, w, h, focus=focus, invalid="Hide", inval=inval)}

    # ---- widgets
    def value_field(self, comps, bg, param, x, y, w, h=CH, size=18, colour=TEXT, editable=True, caption=None, box=True):
        if box:
            bg.field(x, y, w, h)
        if caption:
            bg.caption(x + 1, y - 17, caption)
        key = "vcField_%dx%d_%d_%s_%s" % (w, h, size, colour.lstrip("#"), "e" if editable else "r")
        comps_def = ([focus_sub(w, h)] if editable else []) + [label_sub("Value", "Data", 10, 0, w - 20, h, size, colour)]
        self.define(key, definition([A_QLINK, A_OVERLAY_DBL, A_OVERLAY_ENTER] if editable else [], comps_def, ignore=not editable))
        comps.append(self.place(key, caption or param, x, y, w, h, [("Data", self.p(param))], focus="Yes" if editable else "No"))

    def readout(self, comps, bg, param, x, y, w, h=CH, size=16, colour=TEXT_2, caption=None):
        self.value_field(comps, bg, param, x, y, w, h, size=size, colour=colour, editable=False, caption=caption)

    def stepper(self, comps, bg, param, prev, nxt, x, y, w, caption=None, h=CH):
        """one framed field with chevrons at both ends"""
        bg.field(x, y, w, h)
        bg.a.line(x + h, y + 6, x + h, y + h - 6, FIELD_EDGE)
        bg.a.line(x + w - h, y + 6, x + w - h, y + h - 6, FIELD_EDGE)
        for is_next, px, trig in ((False, x, prev), (True, x + w - h, nxt)):
            off, on = self.img.chevron(is_next), self.img.chevron_pressed(is_next)
            key = self.define("vcChev_%s" % ("next" if is_next else "prev"), definition([A_TOGGLE_ENTER], [button_sub(on, off, 1, 1, h, h)]))
            comps.append(self.place(key, "next" if is_next else "prev", px, y, h, h, [("Data", self.p(trig))]))
        self.value_field(comps, bg, param, x + h, y, w - 2 * h, h, size=18, box=False)
        if caption:
            bg.caption(x + 1, y - 17, caption)

    def segments(self, comps, bg, group, param, labels, x, y, w, h=CH, caption=None):
        if caption:
            bg.caption(x + 1, y - 17, caption)
        n = len(labels)
        for i, t in enumerate(labels):
            on = self.img.seg(group, i, n, t, w, h, True)
            off = self.img.seg(group, i, n, t, w, h, False)
            key = self.define("vcSeg_%s_%d" % (group, i), definition([A_QLINK], [button_sub(on, off, i, n, w, h)]))
            comps.append(self.place(key, "%s %s" % (caption or group, t), x + i * w, y, w, h,
                                    [("Data", self.p(param))], focus="Yes" if i == 0 else "No"))

    def switch(self, comps, bg, param, x, y, caption=None):
        on, off = self.img.switch(True), self.img.switch(False)
        key = self.define("vcSwitch", definition([A_QLINK, A_TOGGLE_ENTER], [focus_sub(44, 24), button_sub(on, off, 1, 1, 44, 24)]))
        if caption:
            bg.caption(x + 1, y - 17, caption)
        comps.append(self.place(key, caption or param, x, y, 44, 24, [("Data", self.p(param))], focus="Yes"))

    def action_button(self, comps, bg, name, text, param, x, y, w=188, h=CH):
        on, off = self.img.button(name, text, w, h, True), self.img.button(name, text, w, h, False)
        key = self.define("vcBtn_%s" % name, definition([A_TOGGLE_ENTER], [button_sub(on, off, 1, 1, w, h)]))
        comps.append(self.place(key, text, x, y, w, h, [("Data", self.p(param))]))

    def pad_grid(self, comps, x0, y0):
        w, h, gap = 148, 120, 8
        for k in range(16):
            on, off = self.img.pad(k + 1, True), self.img.pad(k + 1, False)
            key = self.define("vcPad_%d" % (k + 1), definition([A_QLINK], [
                button_sub(on, off, k + 1, 17, w, h),
                label_sub("Chord", "Chord", 8, 30, w - 16, 40, 26, TEXT),
                label_sub("Function", "Function", 8, 70, w - 16, 24, 14, TEXT_2),
            ]))
            x = x0 + (k % 8) * (w + gap)
            y = y0 + (k // 8) * (h + gap)
            comps.append(self.place(key, "Pad %d" % (k + 1), x, y, w, h,
                                    [("Data", self.p("Screen pad")), ("Chord", self.p("Pad %d chord" % (k + 1))),
                                     ("Function", self.p("Pad %d function" % (k + 1)))]))

    def keyboard(self, comps, param, x0, y0, small=False, dots=False):
        whites = [0, 2, 4, 5, 7, 9, 11]
        ww, wh = (64, 120) if small else (80, 150)
        bw, bh = (40, 74) if small else (48, 90)
        pos = {}
        for i, pc in enumerate(whites):
            pos[pc] = (x0 + i * ww, y0, ww, wh)
        for pc, left in ((1, 0), (3, 2), (6, 5), (8, 7), (10, 9)):
            pos[pc] = (pos[left][0] + ww - bw // 2, y0, bw, bh)
        order = whites + [1, 3, 6, 8, 10]
        for pc in order:
            x, y, w, h = pos[pc]
            on, off = self.img.key(pc, True, small), self.img.key(pc, False, small)
            key = self.define("vc%sKey_%d" % ("E" if small else "", pc), definition([A_QLINK], [button_sub(on, off, pc, 12, w, h)]))
            comps.append(self.place(key, "Key %d" % pc, x, y, w, h, [("Data", self.p(param))]))
        if dots:
            names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
            blank = self.img.blank(14, 14)
            for pc in order:
                black = pc in (1, 3, 6, 8, 10)
                im = self.img.dot(black)
                key = self.define("vcDot_%s" % ("b" if black else "w"), definition([], [button_sub(im, blank, 1, 1, 14, 14)], ignore=True))
                x, y, w, h = pos[pc]
                comps.append(self.place(key, "in scale %s" % names[pc], x + (w - 14) // 2, y + h - (22 if not black else 20), 14, 14,
                                        [("Data", self.p("Scale has %s" % names[pc]))]))

    def step_matrix(self, comps, bg, x0, y0, cw=65, ch=24, gapx=5, gapy=4):
        for g in range(4):  # quiet shading behind every beat (4 steps)
            gx = x0 + g * 4 * (cw + gapx) - 4
            bg.a.rect(gx, y0 - 30, gx + 4 * cw + 3 * gapx + 8, y0 + 7 * (ch + gapy) + 2, 5, fill="#1a1b1f" if g % 2 == 0 else SURFACE)
        for r, (_, label, colour) in enumerate(STEP_ROWS):
            y = y0 + r * (ch + gapy)
            bg.a.rect(x0 - 104, y + 9, x0 - 98, y + 15, 1.5, fill=colour)
            bg.a.text(x0 - 90, y + ch / 2, label.upper(), 10, LABEL, "Medium", anchor="lm", tracking=1.0)
        for k in range(16):
            x = x0 + k * (cw + gapx)
            bg.a.text(x + cw / 2, y0 - 16, str(k + 1), 11, TEXT if k % 4 == 0 else LABEL, "Medium", anchor="mm")
            for r, (state, label, colour) in enumerate(STEP_ROWS):
                on, off = self.img.cell(r, True, cw, ch, colour), self.img.cell(r, False, cw, ch, colour)
                key = self.define("vcCell_%d" % r, definition([A_QLINK], [button_sub(on, off, state, 7, cw, ch)]))
                comps.append(self.place(key, "Step %d %s" % (k + 1, label), x, y0 + r * (ch + gapy), cw, ch,
                                        [("Data", self.p("Step %d" % (k + 1)))], focus="Yes" if r == 1 else "No"))

    # ---- pages
    def page(self, tab_name, fn, comps, bg_name, bg):
        img = self.img.save(bg_name, bg.im)
        background = sub("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": img}, bounds(0, 0, W, H))
        key = "%s|%s" % (tab_name.upper(), tab_name)
        self.define(key, definition([], [background] + comps, bgcolour=argb(BG)))
        self.pages.append({"version": 3, "tabName": tab_name, "fnKeyIndex": fn, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
                           "componentName": key, "initialSize": "0 0 %d %d" % (W, H), "scale": 1.0})

    def header_banks(self, c, bg, group):
        bg.a.text(1066, 28, "BANK", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.segments(c, bg, group, "Screen bank", ["A", "B", "C", "D"], 1076, 12, 45, 32)

    def build(self):
        voicings = ["Bass+upper", "Close", "Drop 2", "Spread", "Upper"]
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        # ---------- Play
        bg = Background("Play")
        c = []
        self.segments(c, bg, "mode", "Mode", ["Song", "Scale", "R&B kit", "Types", "Custom"], 456, 12, 104, 32)
        self.header_banks(c, bg, "bank")
        bg.panel((12, 64, 1268, 144))
        self.stepper(c, bg, "Song", "Song prev", "Song next", 28, 96, 548, "Song")
        self.stepper(c, bg, "Section", "Section prev", "Section next", 592, 96, 300, "Section")
        self.readout(c, bg, "Info", 908, 96, 344, size=14, caption="Song data")
        bg.panel((12, 152, 1268, 416))
        self.pad_grid(c, 20, 160)
        bg.panel((12, 424, 600, 620))
        bg.caption(28, 436, "Key")
        bg.a.text(588, 436, "DOTS MARK THE SCALE", 9.5, "#4d5159", "Medium", anchor="ra", tracking=1.0)
        self.keyboard(c, "Key", 28, 456, dots=True)
        bg.panel((608, 424, 1268, 620))
        self.stepper(c, bg, "Scale", "Scale prev", "Scale next", 624, 456, 628, "Scale")
        self.segments(c, bg, "smart", "Smart pads", ["Off", "Pads 9-16", "Follow"], 624, 518, 110, caption="Smart Scale pads")
        self.segments(c, bg, "smartn", "Smart notes", ["Chord", "Scale", "Bass"], 964, 518, 96, caption="Smart notes")
        self.readout(c, bg, "Now playing", 624, 566, 628, 40, size=17, colour=ACCENT)
        self.page("Play", 0, c, "vc_bg_play.png", bg)

        # ---------- Perform
        bg = Background("Perform")
        c = []
        L, R = 28, 664
        rows = [100, 184, 268, 352, 436, 520]
        bg.panel((12, 64, 632, 620))
        self.segments(c, bg, "sound", "Sound", ["E. piano", "Pad", "Organ", "Silent"], L, rows[0], 147, caption="Instrument")
        self.value_field(c, bg, "Tone", L, rows[1], 188, caption="Tone")
        self.value_field(c, bg, "Release", L + 200, rows[1], 188, caption="Release")
        self.value_field(c, bg, "Volume", L + 400, rows[1], 188, caption="Volume")
        self.segments(c, bg, "vel", "Velocity", ["Linear", "Soft", "Hard", "Fixed"], L, rows[2], 147, caption="Velocity")
        self.value_field(c, bg, "Strum", L, rows[3], 188, caption="Strum")
        self.segments(c, bg, "strumdir", "Strum dir", ["Up", "Down", "Alternate"], L + 204, rows[3], 128, caption="Strum direction")
        self.segments(c, bg, "arp", "Arp", ["Off", "Up", "Down", "Up-down", "Random"], L, rows[4], 117, caption="Arpeggiator")
        self.segments(c, bg, "rate", "Arp rate", ["1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"], L, rows[5], 98, caption="Arp rate")
        bg.panel((648, 64, 1268, 620))
        self.segments(c, bg, "voicing2", "Voicing", voicings, R, rows[0], 117, caption="Voicing")
        self.segments(c, bg, "inv", "Inversion", ["Root", "1st", "2nd", "3rd"], R, rows[1], 147, caption="Inversion")
        self.segments(c, bg, "oct", "Octave", ["-2", "-1", "0", "+1", "+2"], R, rows[2], 117, caption="Octave")
        self.value_field(c, bg, "Transpose", R, rows[3], 188, caption="Transpose (song)")
        self.switch(c, bg, "Voice lead", R + 204, rows[3] + 6, "Voice leading")
        self.value_field(c, bg, "MIDI out", R + 336, rows[3], 252, caption="MIDI out")
        self.value_field(c, bg, "Pad 1 note", R, rows[4], 188, caption="Pad 1 note")
        self.action_button(c, bg, "learn", "Learn pad 1", "Learn pad 1", R + 204, rows[4])
        self.action_button(c, bg, "export", "Export MIDI", "Export MIDI", R, rows[5])
        self.readout(c, bg, "Export MIDI", R + 204, rows[5], 384, size=14)
        self.page("Perform", 1, c, "vc_bg_perform.png", bg)

        # ---------- Edit
        bg = Background("Edit pads")
        c = []
        bg.a.text(466, 28, "PAD", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.stepper(c, bg, "Edit pad", "Edit pad prev", "Edit pad next", 476, 10, 180)
        bg.a.text(866, 28, "TAP SELECTS", 10.5, LABEL, "Medium", anchor="rm", tracking=1.3)
        self.switch(c, bg, "Edit follows pad", 876, 16)
        self.header_banks(c, bg, "bank3")
        bg.panel((12, 64, 1268, 328))
        self.pad_grid(c, 20, 72)
        bg.panel((12, 336, 484, 620))
        bg.caption(28, 348, "Root")
        self.keyboard(c, "Edit root", 28, 368, small=True)
        self.action_button(c, bg, "copy", "Copy layout to Custom", "Copy to Custom", 28, 568, w=440)
        bg.panel((492, 336, 1268, 620))
        self.segments(c, bg, "bass", "Edit bass", ["Root"] + notes, 508, 368, 56, caption="Bass note")
        self.stepper(c, bg, "Edit type", "Edit type prev", "Edit type next", 508, 450, 520, "Chord type")
        self.readout(c, bg, "Now playing", 1044, 450, 208, size=13, colour=ACCENT, caption="Now playing")
        self.segments(c, bg, "einv", "Edit inversion", ["Root", "1st", "2nd", "3rd"], 508, 532, 88, caption="Inversion")
        self.segments(c, bg, "eoct", "Edit octave", ["-2", "-1", "0", "+1", "+2"], 900, 532, 70, caption="Octave")
        self.page("Edit", 2, c, "vc_bg_edit.png", bg)

        # ---------- Pattern
        bg = Background("Pattern")
        c = []
        bg.panel((12, 64, 1268, 144))
        self.stepper(c, bg, "Pattern", "Pattern prev", "Pattern next", 28, 96, 420, "Pattern")
        self.segments(c, bg, "prate", "Pattern rate", ["1/8", "1/8T", "1/16", "1/16T", "1/32"], 492, 96, 78, caption="Step length")
        self.segments(c, bg, "psync", "Pattern sync", ["Free", "Follow MPC"], 912, 96, 170, caption="Timing")
        bg.panel((12, 152, 1268, 408))
        self.step_matrix(c, bg, 132, 196)
        bg.panel((12, 416, 1268, 620))
        r1, r2 = 450, 542
        self.value_field(c, bg, "Swing", 28, r1, 150, caption="Swing")
        self.value_field(c, bg, "Gate", 190, r1, 150, caption="Note length")
        self.segments(c, bg, "sound3", "Sound", ["E. piano", "Pad", "Organ", "Silent"], 360, r1, 116, caption="Built-in sound")
        self.value_field(c, bg, "MIDI channel", 844, r1, 120, caption="Out channel")
        self.readout(c, bg, "Now playing", 980, r1, 272, size=13, colour=ACCENT, caption="Now playing")
        self.segments(c, bg, "mout", "MIDI out", ["Off", "To MPC", "Virtual port", "Both"], 28, r2, 150, caption="Send chords as MIDI")
        self.readout(c, bg, "MIDI port", 644, r2, 608, size=14, caption="Virtual port: Velvet Chords Out")
        self.page("Pattern", 3, c, "vc_bg_pattern.png", bg)

    def tui(self):
        return {"pageData": {"version": 1, "componentDefinitions": {"version": 2, "importFiles": [
            "/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
            "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
            "localComponentDefinitions": [{"key": k, "value": v} for k, v in self.defs.items()]},
            "info": {"version": 1, "type": "CompleteDescription"}, "tabs": self.pages}}

    def qlinks(self):
        def m(names):
            names = (names + [None] * 16)[:16]
            return {"Q-Link %d" % (i + 1): (self.p(n) if n else -1) for i, n in enumerate(names)}
        play = ["Mode", "Song", "Section", "Screen bank", "Key", "Scale", "Transpose", "Voicing",
                "Inversion", "Octave", "Voice lead", "Sound", "Smart pads", "Smart notes", "Smart octave", "Volume"]
        perform = ["Sound", "Tone", "Release", "Volume", "Velocity", "Strum", "Strum dir", "Arp",
                   "Arp rate", "Voicing", "Inversion", "Octave", "Transpose", "Voice lead", "MIDI out", "Pad 1 note"]
        edit = ["Edit pad", "Edit root", "Edit type", "Edit bass", "Edit inversion", "Edit octave", "Edit follows pad",
                "Screen bank", "Mode", "Voicing", "Sound", "Volume"]
        pattern = ["Step %d" % (k + 1) for k in range(16)]
        tabs = [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": m(x)} for i, x in enumerate([play, perform, edit, pattern])]
        return {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
                "Screen Mode Q-Links": {"version": 4, "map": tabs}, "Program Mode Q-Links": m(play)}


def main():
    so, lister, out = sys.argv[1], sys.argv[2], sys.argv[3]
    params = load_params(so, lister)
    skin_dir = os.path.join(out, "Velvet Chords - VST - Velvet Chords")
    os.makedirs(skin_dir, exist_ok=True)
    s = Skin(params, skin_dir)
    s.build()
    json.dump(s.tui(), open(os.path.join(skin_dir, "TUI.json"), "w"), indent=4)
    q = s.qlinks()
    for name in ("Q-Links.json", "Q-Links - 8by1.json"):
        json.dump(q, open(os.path.join(skin_dir, name), "w"), indent=4)
    print("skin: %s (%d definitions, %d pages, %d images)" % (skin_dir, len(s.defs), len(s.pages), len(s.img.made)))


if __name__ == "__main__":
    main()
